﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AssessmentCode.Controllers;

namespace AssessmentCode.Tests.Controllers
{
    [TestClass]

    public class ReadAssessmentManagerControllerTest
    {
        /// <summary>
        /// Test Method - ReadXMLData
        /// </summary>
        [TestMethod]
    public void ReadXMLData()
    {
        //Arrange
        ReadAssessmentManagerController rAMController = new ReadAssessmentManagerController();

        var result = rAMController.GetAllPatients();

        Assert.IsNotNull(result.Count.ToString());
    }

    [TestMethod]
    public void ReadXMLDataList()
    {
        //Arrange
        ReadAssessmentManagerController rAMController = new ReadAssessmentManagerController();

        var result = rAMController.GetAllPatients();

        Assert.IsNotNull(result.Count.ToString());
    }
}
}
