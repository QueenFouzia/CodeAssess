﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AssessmentCode.Controllers;
using AssessmentCode.Models;

namespace AssessmentCode.Tests.Controllers
{
    [TestClass]
    public class CreateAssessmentManagerControllerTest
    {
        /// <summary>
        /// SaveAssessment
        /// </summary>
        [TestMethod]
        public void SaveAssessment()
        {
            //Arrange
            CreateAssessmentManagerController cAMController = new CreateAssessmentManagerController();

            Assessment patientMoc = new Assessment()
            {
                Forename = "William James",
                Surname = "WJ",
                DOBDateTime = DateTime.Now,
                Gender = "",
                HomeNumber = "9876543212",
                WorkNumber = "0809765434",
                MobileNumber = "8765432145"
            };
            var result = cAMController.SavePatient(patientMoc);

            //Assert
            Assert.IsNotNull(result.Length != 0);
        }
    }
}

