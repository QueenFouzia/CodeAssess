﻿using AssessmentCode.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Xml.Linq;

namespace AssessmentCode.Controllers
{
    public class ReadAssessmentManagerController : ApiController
    {
        /// <summary>
        /// ApiController - GetAllPatients 
        /// Gives the list of Patients Assessment Records
        /// </summary>
        /// <returns></returns>
        public List<Assessment> GetAllPatients()
        {
            List<Assessment> assessments = new List<Assessment>();
            XDocument doc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/Assessment.xml"));

            foreach (XElement element in doc.Descendants("Assessment").Descendants("Item"))
            {
                Assessment assessment = new Assessment();

                assessment.Forename = element.Element("Forename").Value;
                assessment.Surname = element.Element("Surname").Value;
                assessment.Gender = element.Element("Gender").Value;
                assessment.DOB = element.Element("DateOfBirth").Value;


                assessments.Add(assessment);
            }
            return assessments;

        }
    }
}
