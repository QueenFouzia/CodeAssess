﻿using AssessmentCode.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Xml.Linq;

namespace AssessmentCode.Controllers
{
    public class CreateAssessmentManagerController : ApiController
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="patient"></param>
        /// <returns></returns>
        [HttpPost]
        public string SavePatient(Assessment assessment)
        {

            XDocument doc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/Assessment.xml"));
            var patientNode = doc.Descendants("Assessment").FirstOrDefault();
            if (patientNode != null)
            {
                patientNode.Add(new XElement("Item",
                         new XElement("Forename", assessment.Forename),
                         new XElement("Surname", assessment.Surname),
                         new XElement("Gender", assessment.Gender),
                         new XElement("DateOfBirth", String.Format("{0:d/M/yyyy}", assessment.DOBDateTime)),
                         new XElement("TelephoneNumber",
                                new XElement("HomeNumber", assessment.HomeNumber != null ? assessment.HomeNumber : ""),
                                new XElement("WorkNumber", assessment.WorkNumber != null ? assessment.WorkNumber : ""),
                                new XElement("MobileNumber", assessment.MobileNumber != null ? assessment.MobileNumber : ""))
                                ));

            }
            doc.Save(HttpContext.Current.Server.MapPath("~/App_Data/Assessment.xml"));

            return "true";
        }
    }
}
