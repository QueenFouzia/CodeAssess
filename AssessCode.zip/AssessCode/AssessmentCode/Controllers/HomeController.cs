﻿using AssessmentCode.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AssessmentCode.Controllers
{
    public class HomeController : Controller
    {
        /// <summary>
        /// Index - Loads the Home Page with the Patient List 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            var patientList = new ReadAssessmentManagerController().GetAllPatients();
            return View("Index", patientList);
        }

        /// <summary>
        /// Save - Renders the Save View
        /// </summary>
        /// <returns></returns>
        public ActionResult Save()
        {
            return View();
        }

        /// <summary>
        /// AddPatient - Post method - Creates the Patient Assessment record.
        /// </summary>
        /// <param name="patientAssesment"></param>
        /// <returns></returns>
        public ActionResult AddPatient(Assessment assesment)
        {
            ViewBag.Title = "Add Patient";
            var createPatient = new CreateAssessmentManagerController().SavePatient(assesment);
            var patientList = new ReadAssessmentManagerController().GetAllPatients();

            return View("Index", patientList);
        }
    }
}
